 import react from "react";

export const Udata=[
         {
              Q:"Q1.Is MSME registration and udyog Aadhar registration is same?",
              Ans:"Ans : Yes, MSME registration becomes Udyog Aadhar registration."
         },

         {
            Q:"Q2.What is the purpose of a PAN card?",
            Ans:"Ans : Yes, MSME registration becomes Udyog Aadhar registration."
       }

]