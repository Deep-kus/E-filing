export const MenuItems2 = [
    {
      title: 'GST Return Filing (Monthly/ Quarterly)',
      path: '/gstreturn',
      cName: 'dropdown-link'
    },
    {
      title: 'GST LUT Filing',
      path: '/lutfiling',
      cName: 'dropdown-link'
    },
    {
      title: 'GST Annual Return',
      path: '/gstannual',
      cName: 'dropdown-link'
    },
    {
      title: 'Income Tax Return Filing',
      path: '/itr',
      cName: 'dropdown-link'
    },
    {
        title: 'Business Tax Filing ',
        path: '/business',
        cName: 'dropdown-link'
      },
      {
        title: 'HUF Return Filing',
        path: '/huf',
        cName: 'dropdown-link'
      },
      {
        title: 'Corporate Tax Return',
        path: '/corporate',
        cName: 'dropdown-link'
      },
      {
        title: 'Society Tax Return ',
        path: 'society',
        cName: 'dropdown-link'
      },
      {
        title: 'Salary Class Tax Return',
        path: 'salary',
        cName: 'dropdown-link'
      },
      {
        title: 'TDS Filing ',
        path: 'tds',
        cName: 'dropdown-link'
      },
      {
        title: 'Professional Tax Return Filing ',
        path: 'taxreturn',
        cName: 'dropdown-link'
      },
      {
        title: 'VAT Tax Return Filing. ',
        path: 'vat',
        cName: 'dropdown-link'
      },
      {
        title: 'VAT Tax Return Filing. ',
        path: 'vat',
        cName: 'dropdown-link'
      }
  ];