export const MenuItems1 = [
    {
      title: 'UDYAM/MSME',
      path: '/udyam',
      cName: 'dropdown-link'
    },
    {
      title: 'FSSAI Registration',
      path: '/fssai',
      cName: 'dropdown-link'
    },
    {
      title: 'Import Export Code',
      path: '/import',
      cName: 'dropdown-link'
    },
    {
      title: 'Professional Tax',
      path: '/professional',
      cName: 'dropdown-link'
    },
    {
        title: 'Shop and Establishment Registration (Gumasta) ',
        path: '/gumasta',
        cName: 'dropdown-link'
      },
      {
        title: 'Partnership Firm Registration with RFS                     ',
        path: '/rfs',
        cName: 'dropdown-link'
      },
      {
        title: 'Society/ Trust Registration                       ',
        path: '/society',
        cName: 'dropdown-link'
      },
      {
        title: 'GST Registration ',
        path: 'gst',
        cName: 'dropdown-link'
      },
      {
        title: 'GST Registration Cancellation ',
        path: 'gstcancel',
        cName: 'dropdown-link'
      },
      {
        title: 'PAN and TAN Registration ',
        path: 'pantan',
        cName: 'dropdown-link'
      },
      {
        title: 'VAT Registration ',
        path: 'vat',
        cName: 'dropdown-link'
      },
      {
        title: 'PF / ESI Registration ',
        path: 'pf',
        cName: 'dropdown-link'
      }
  ];