export const MenuItems = [
    {
      title: 'Proprietorship Registration',
      path: '/proprietoship',
      cName: 'dropdown-link'
    },
    {
      title: 'Firm Registration',
      path: '/firm',
      cName: 'dropdown-link'
    },
    {
      title: 'One Person Company (OPC)',
      path: '/opc',
      cName: 'dropdown-link'
    },
    {
      title: 'Pvt. Ltd. Company',
      path: '/pvt',
      cName: 'dropdown-link'
    },
    {
        title: 'Public Ltd. Company ',
        path: '/public',
        cName: 'dropdown-link'
      },
      {
        title: 'Limited Liability Partnership (LLP)                        ',
        path: '/llp',
        cName: 'dropdown-link'
      },
      {
        title: 'Producer Company                       ',
        path: '/pc',
        cName: 'dropdown-link'
      },
      {
        title: 'Section 8 Company                      ',
        path: '/sc',
        cName: 'dropdown-link'
      }
  ];